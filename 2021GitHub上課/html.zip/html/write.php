<!DOCTYPE html>
<html>
<head>
<title="text page">
<meta charset="UTF-8">
<style>


body {background-color:white;} //背景顏色調整


</style>
</head>
<body>
<form action="writex.php" method="post"  id="usrform">
<p>輸入文字(使用< br >以進行換行):</p>
<br><br>
<textarea rows="4" cols="50" name="name" form="usrform">
<?php
$myfile = fopen("TEXT.txt", "r") or die("");
echo fread($myfile,filesize("TEXT.txt"));
fclose($myfile);
?>   
</textarea>

<input type ="submit" value="送出">
</form>
    

</body>
</html>
