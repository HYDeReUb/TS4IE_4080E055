<!DOCTYPE html>
<html>
<head>
<title="text page">
<meta charset="UTF-8">
<meta http-equiv="refresh" content="20">
</head>
<body>
<div style="font-size:400%;padding-left:20%;padding-right:20%;"><!--7行字2行600% 3行550% 8字3行520%--><p>
<?php
$myfile = fopen("TEXT.txt", "r") or die("Unknown Files!");
echo fread($myfile,filesize("TEXT.txt"));
fclose($myfile);
?>

<!--寫入結束-->
</p></div>

</body>
</html>
