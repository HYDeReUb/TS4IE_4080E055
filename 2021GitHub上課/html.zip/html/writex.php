<!DOCTYPE html>
<html>
<head>
<title="text page">
<meta charset="UTF-8">
<style>


body {background-color:white;} //背景顏色調整


</style>
</head>
<body>

    
<?php
$name = $_POST['name'];
$myfile = fopen("TEXT.txt", "w") or die("Unable to open file!");

fwrite($myfile, $txt);
$txt = "$name";
fwrite($myfile, $txt);
fclose($myfile);
?>

<h2>已寫入</h2>
<a href="index.php">回主畫面</a> | <a href="write.php">編輯</a>

</body>
</html>
